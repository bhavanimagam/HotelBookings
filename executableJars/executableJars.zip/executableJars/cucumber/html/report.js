$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/HotelBookingsTest.feature");
formatter.feature({
  "line": 1,
  "name": "Save and Delete Bookings",
  "description": "In order to verify that hotel booking sire\nAs a user of hotel booking site\nI should be able to save and delete the booking",
  "id": "save-and-delete-bookings",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 7,
  "name": "Save and delete the booking",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 6,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I enter the fields with the values \u0027\u003cFirstName\u003e\u0027, \u0027\u003cLastName\u003e\u0027, \u0027\u003cPrice\u003e\u0027, \u0027\u003cDeposit\u003e\u0027, \u0027\u003cCheckin\u003e\u0027, \u0027\u003cCheckout\u003e\u0027 and click on Save",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should find a booking with the values \u0027\u003cFirstName\u003e\u0027, \u0027\u003cLastName\u003e\u0027, \u0027\u003cPrice\u003e\u0027, \u0027\u003cDeposit\u003e\u0027, \u0027\u003cCheckin\u003e\u0027, \u0027\u003cCheckout\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I delete the booking with the value \u0027\u003cFirstName\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I should not find a booking with the value \u0027\u003cFirstName\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking;",
  "rows": [
    {
      "cells": [
        "FirstName",
        "LastName",
        "Price",
        "Deposit",
        "Checkin",
        "Checkout"
      ],
      "line": 14,
      "id": "save-and-delete-bookings;save-and-delete-the-booking;;1"
    },
    {
      "cells": [
        "Magam_1234",
        "Magam_1234",
        "200",
        "true",
        "2019-07-01",
        "2019-07-03"
      ],
      "line": 15,
      "id": "save-and-delete-bookings;save-and-delete-the-booking;;2"
    },
    {
      "cells": [
        "Magam_**$^\u0026",
        "Magam_**$^\u0026",
        "20",
        "false",
        "2019-10-01",
        "2019-12-03"
      ],
      "line": 16,
      "id": "save-and-delete-bookings;save-and-delete-the-booking;;3"
    },
    {
      "cells": [
        "Magam_**$^\u0026",
        "Magam_**$^\u0026",
        "1000000000000",
        "false",
        "2019-10-01",
        "2019-12-03"
      ],
      "line": 17,
      "id": "save-and-delete-bookings;save-and-delete-the-booking;;4"
    },
    {
      "cells": [
        ".",
        "Magam_**$^\u0026 0000000",
        "1000000000000",
        "false",
        "2019-12-31",
        "2020-02-20"
      ],
      "line": 18,
      "id": "save-and-delete-bookings;save-and-delete-the-booking;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 2096703766,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "Save and delete the booking",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 6,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I enter the fields with the values \u0027Magam_1234\u0027, \u0027Magam_1234\u0027, \u0027200\u0027, \u0027true\u0027, \u00272019-07-01\u0027, \u00272019-07-03\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should find a booking with the values \u0027Magam_1234\u0027, \u0027Magam_1234\u0027, \u0027200\u0027, \u0027true\u0027, \u00272019-07-01\u0027, \u00272019-07-03\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I delete the booking with the value \u0027Magam_1234\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I should not find a booking with the value \u0027Magam_1234\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1802061476,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_1234",
      "offset": 36
    },
    {
      "val": "Magam_1234",
      "offset": 50
    },
    {
      "val": "200",
      "offset": 64
    },
    {
      "val": "true",
      "offset": 71
    },
    {
      "val": "2019-07-01",
      "offset": 79
    },
    {
      "val": "2019-07-03",
      "offset": 93
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 544484094,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_1234",
      "offset": 41
    },
    {
      "val": "Magam_1234",
      "offset": 55
    },
    {
      "val": "200",
      "offset": 69
    },
    {
      "val": "true",
      "offset": 76
    },
    {
      "val": "2019-07-01",
      "offset": 84
    },
    {
      "val": "2019-07-03",
      "offset": 98
    }
  ],
  "location": "HotelBookingStepDef.i_should_find_a_booking_with_the_values(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 2815590397,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_1234",
      "offset": 37
    }
  ],
  "location": "HotelBookingStepDef.i_delete_the_booking_with_the_value(String)"
});
formatter.result({
  "duration": 616694730,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_1234",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 12423786,
  "status": "passed"
});
formatter.after({
  "duration": 73095204,
  "status": "passed"
});
formatter.before({
  "duration": 1548296004,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Save and delete the booking",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 6,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I enter the fields with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_**$^\u0026\u0027, \u002720\u0027, \u0027false\u0027, \u00272019-10-01\u0027, \u00272019-12-03\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should find a booking with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_**$^\u0026\u0027, \u002720\u0027, \u0027false\u0027, \u00272019-10-01\u0027, \u00272019-12-03\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I delete the booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I should not find a booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1853793410,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 36
    },
    {
      "val": "Magam_**$^\u0026",
      "offset": 51
    },
    {
      "val": "20",
      "offset": 66
    },
    {
      "val": "false",
      "offset": 72
    },
    {
      "val": "2019-10-01",
      "offset": 81
    },
    {
      "val": "2019-12-03",
      "offset": 95
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 557322655,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 41
    },
    {
      "val": "Magam_**$^\u0026",
      "offset": 56
    },
    {
      "val": "20",
      "offset": 71
    },
    {
      "val": "false",
      "offset": 77
    },
    {
      "val": "2019-10-01",
      "offset": 86
    },
    {
      "val": "2019-12-03",
      "offset": 100
    }
  ],
  "location": "HotelBookingStepDef.i_should_find_a_booking_with_the_values(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 3280764272,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 37
    }
  ],
  "location": "HotelBookingStepDef.i_delete_the_booking_with_the_value(String)"
});
formatter.result({
  "duration": 608521623,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 12101925,
  "status": "passed"
});
formatter.after({
  "duration": 75347227,
  "status": "passed"
});
formatter.before({
  "duration": 1544284860,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Save and delete the booking",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 6,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I enter the fields with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_**$^\u0026\u0027, \u00271000000000000\u0027, \u0027false\u0027, \u00272019-10-01\u0027, \u00272019-12-03\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should find a booking with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_**$^\u0026\u0027, \u00271000000000000\u0027, \u0027false\u0027, \u00272019-10-01\u0027, \u00272019-12-03\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I delete the booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I should not find a booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1802033087,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 36
    },
    {
      "val": "Magam_**$^\u0026",
      "offset": 51
    },
    {
      "val": "1000000000000",
      "offset": 66
    },
    {
      "val": "false",
      "offset": 83
    },
    {
      "val": "2019-10-01",
      "offset": 92
    },
    {
      "val": "2019-12-03",
      "offset": 106
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 591476940,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 41
    },
    {
      "val": "Magam_**$^\u0026",
      "offset": 56
    },
    {
      "val": "1000000000000",
      "offset": 71
    },
    {
      "val": "false",
      "offset": 88
    },
    {
      "val": "2019-10-01",
      "offset": 97
    },
    {
      "val": "2019-12-03",
      "offset": 111
    }
  ],
  "location": "HotelBookingStepDef.i_should_find_a_booking_with_the_values(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 4846700563,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 37
    }
  ],
  "location": "HotelBookingStepDef.i_delete_the_booking_with_the_value(String)"
});
formatter.result({
  "duration": 606078824,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 10779676,
  "status": "passed"
});
formatter.after({
  "duration": 73781793,
  "status": "passed"
});
formatter.before({
  "duration": 1599908444,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Save and delete the booking",
  "description": "",
  "id": "save-and-delete-bookings;save-and-delete-the-booking;;5",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 6,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I enter the fields with the values \u0027.\u0027, \u0027Magam_**$^\u0026 0000000\u0027, \u00271000000000000\u0027, \u0027false\u0027, \u00272019-12-31\u0027, \u00272020-02-20\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I should find a booking with the values \u0027.\u0027, \u0027Magam_**$^\u0026 0000000\u0027, \u00271000000000000\u0027, \u0027false\u0027, \u00272019-12-31\u0027, \u00272020-02-20\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I delete the booking with the value \u0027.\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I should not find a booking with the value \u0027.\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1761363032,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": ".",
      "offset": 36
    },
    {
      "val": "Magam_**$^\u0026 0000000",
      "offset": 41
    },
    {
      "val": "1000000000000",
      "offset": 64
    },
    {
      "val": "false",
      "offset": 81
    },
    {
      "val": "2019-12-31",
      "offset": 90
    },
    {
      "val": "2020-02-20",
      "offset": 104
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 581199469,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": ".",
      "offset": 41
    },
    {
      "val": "Magam_**$^\u0026 0000000",
      "offset": 46
    },
    {
      "val": "1000000000000",
      "offset": 69
    },
    {
      "val": "false",
      "offset": 86
    },
    {
      "val": "2019-12-31",
      "offset": 95
    },
    {
      "val": "2020-02-20",
      "offset": 109
    }
  ],
  "location": "HotelBookingStepDef.i_should_find_a_booking_with_the_values(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 3806486702,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": ".",
      "offset": 37
    }
  ],
  "location": "HotelBookingStepDef.i_delete_the_booking_with_the_value(String)"
});
formatter.result({
  "duration": 609014336,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": ".",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 11422491,
  "status": "passed"
});
formatter.after({
  "duration": 74140261,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 22,
  "name": "Save fails when I don\u0027t fill mandatory fields",
  "description": "",
  "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "I enter the fields with the values \u0027\u003cFirstName\u003e\u0027, \u0027\u003cLastName\u003e\u0027, \u0027\u003cPrice\u003e\u0027, \u0027\u003cDeposit\u003e\u0027, \u0027\u003cCheckin\u003e\u0027, \u0027\u003cCheckout\u003e\u0027 and click on Save",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I should not find a booking with the value \u0027\u003cFirstName\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 26,
  "name": "",
  "description": "",
  "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;",
  "rows": [
    {
      "cells": [
        "FirstName",
        "LastName",
        "Price",
        "Deposit",
        "Checkin",
        "Checkout"
      ],
      "line": 27,
      "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;1"
    },
    {
      "cells": [
        "Magam_**$^\u0026",
        "",
        "200",
        "true",
        "2019-07-01",
        "2019-07-03"
      ],
      "line": 28,
      "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;2"
    },
    {
      "cells": [
        "Magam_**$^\u0026",
        "Magam_1234",
        "",
        "false",
        "2019-10-01",
        ""
      ],
      "line": 29,
      "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;3"
    },
    {
      "cells": [
        "Magam_**$^\u0026",
        "Magam_1234",
        "0",
        "false",
        "2019000000",
        ""
      ],
      "line": 30,
      "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1622777133,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Save fails when I don\u0027t fill mandatory fields",
  "description": "",
  "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "I enter the fields with the values \u0027Magam_**$^\u0026\u0027, \u0027\u0027, \u0027200\u0027, \u0027true\u0027, \u00272019-07-01\u0027, \u00272019-07-03\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I should not find a booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1839670919,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 36
    },
    {
      "val": "",
      "offset": 51
    },
    {
      "val": "200",
      "offset": 55
    },
    {
      "val": "true",
      "offset": 62
    },
    {
      "val": "2019-07-01",
      "offset": 70
    },
    {
      "val": "2019-07-03",
      "offset": 84
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 499228124,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 13428703,
  "status": "passed"
});
formatter.after({
  "duration": 73753207,
  "status": "passed"
});
formatter.before({
  "duration": 1552376759,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Save fails when I don\u0027t fill mandatory fields",
  "description": "",
  "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "I enter the fields with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_1234\u0027, \u0027\u0027, \u0027false\u0027, \u00272019-10-01\u0027, \u0027\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I should not find a booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1561960591,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 36
    },
    {
      "val": "Magam_1234",
      "offset": 51
    },
    {
      "val": "",
      "offset": 65
    },
    {
      "val": "false",
      "offset": 69
    },
    {
      "val": "2019-10-01",
      "offset": 78
    },
    {
      "val": "",
      "offset": 92
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 513301679,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 14011601,
  "status": "passed"
});
formatter.after({
  "duration": 74954749,
  "status": "passed"
});
formatter.before({
  "duration": 1547124797,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Save fails when I don\u0027t fill mandatory fields",
  "description": "",
  "id": "save-and-delete-bookings;save-fails-when-i-don\u0027t-fill-mandatory-fields;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@eentest"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "I access equal experts hotel booking site",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "I enter the fields with the values \u0027Magam_**$^\u0026\u0027, \u0027Magam_1234\u0027, \u00270\u0027, \u0027false\u0027, \u00272019000000\u0027, \u0027\u0027 and click on Save",
  "matchedColumns": [
    0,
    1,
    2,
    3,
    4,
    5
  ],
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "I should not find a booking with the value \u0027Magam_**$^\u0026\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "HotelBookingStepDef.I_access_experis_hotel_booking_site()"
});
formatter.result({
  "duration": 1589041991,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 36
    },
    {
      "val": "Magam_1234",
      "offset": 51
    },
    {
      "val": "0",
      "offset": 65
    },
    {
      "val": "false",
      "offset": 70
    },
    {
      "val": "2019000000",
      "offset": 79
    },
    {
      "val": "",
      "offset": 93
    }
  ],
  "location": "HotelBookingStepDef.i_enter_the_fields_with_the_values_and_click_on_Save(String,String,String,String,String,String)"
});
formatter.result({
  "duration": 505842651,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Magam_**$^\u0026",
      "offset": 44
    }
  ],
  "location": "HotelBookingStepDef.i_should_not_find_a_booking_with_the_value(String)"
});
formatter.result({
  "duration": 13037843,
  "status": "passed"
});
formatter.after({
  "duration": 74946396,
  "status": "passed"
});
});